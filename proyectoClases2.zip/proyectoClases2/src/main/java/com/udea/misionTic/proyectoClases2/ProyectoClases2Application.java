package com.udea.misionTic.proyectoClases2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoClases2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoClases2Application.class, args);
	}

}
